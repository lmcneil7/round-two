window.addEventListener('DOMContentLoaded',init,false);
            
function init() {
    alert('welcome!');
    var buttons = document.getElementsbyTagName("button")
buttons[0].addEventListener('click', moreInfo, false)
}

function moreInfo() {
    
window.location=''
}